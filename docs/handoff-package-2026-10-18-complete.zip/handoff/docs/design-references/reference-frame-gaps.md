# 参考帧缺口规格书（P0 / P2 共用）

> 任务书 §4.2：「至少具备普通文字、回复选择、图片消息三类完整游戏参考帧。元件表只能证明
> 头像与符号来源，不能单独证明整屏布局已还原。**缺少某类参考时，对应界面的还原验收必须标记为未完成**。」
> 本文件把「缺什么、缺到什么程度、怎么补、补到什么标准算够」写死，避免用近似素材冒充。

## 1. 缺口总表

| # | 缺口 | 影响验收项 | 现状 | 严重度 |
| --- | --- | --- | --- | --- |
| G1 | **普通文字消息完整帧** | §4.2 普通文字消息 / §8.1「三类完整参考帧」 | ✅ **已有完整帧（2026-10-18）**：普通对话整屏 ×2（PS 官方 CDN 4K + 本地导入 Maruki）+ IM 完整屏 ×2（群聊/含图片消息，1920×1080/1280×720），可作为文字消息与整屏布局对照；**仍不覆盖**「对方→我方→对方」的发送方气泡帧与时间戳位置（无该样例） | 可做整屏布局对照；交互细节仍标未完成 |
| G2 | **回复选择完整帧** | §4.2 剧情回复 / §8.1 | ✅ **已补齐（2026-10-18）**：站主提供 `hud/p5r-im-reply-selection-fullframe.jpg`（P5R SNS 红面板 + 白色箭头回复选项）；P4 选项帧仍只作辅助参考 | 已关闭；不再用 P4 帧冒充 |
| G3 | **异世界导航经典红眼图标原图** | §2.3 图标 / §4.7 | ⚠️ **已落地（验收 F2 返工，2026-10-17）**：本地 HUD 表仍无独立原图；改用可追溯外部清理版（Imgur）+ P5 动画原版画面证据，接入桌面实际渲染 `app/original/metanav-original.png`；属「原版视觉清理版」，不宣称官方原始矢量。详见 `original-app-icons.md` | 已接入；官方原始 sprites 仍未入库 |
| G4 | 图片消息完整帧（**来源未核实**） | §4.2 图片消息 | ⚠️ **部分补齐（2026-10-18）**：图片消息完整帧仍为 `p5r-im-photo-fullframe.jpg`（本地导入，原始 URL 未核实；即原 `p5r-sns`）；另补 IM 群聊完整帧（Pinterest 图片直链，原始发布 URL 未核实）。**来源核实仍不通过** | 可做布局对照；来源与 B4 图片消息协议仍待解决 |

## 2. 每个缺口要什么

### G1 普通文字消息完整帧

- **必须整屏**：包含手机外壳或至少完整的聊天画面边界，能看出发送方 / 接收方的气泡位置、
  头像位置与尺寸、气泡宽度比例、行距、时间戳位置。
- 至少 **2 条会话往返**（对方→我方→对方），才能判断左右对齐与间距。
- 版本标注到 **P5 或 P5R**（两者 IM 布局有差异，不能混用）。
- 若来自视频：记录**视频链接 + 时间点**。
- **不接受**：只有气泡元件的裁剪图、只有头像的图、截图里带其他 UI 遮挡的半屏。

### G2 回复选择完整帧（✅ 2026-10-18 已补齐）

- 必须显示**回复选项列表**（2 个以上选项）+ 输入区域，能看出选项的选中态、禁用态与排列方式。
- 需要能判断：选项是叠加在聊天上还是替换输入区、选中时的反色/描边方式、多选项时的间距。
- 版本标注同上。

### G3 异世界导航经典红眼图标

- **红眼 + 星形瞳孔 + 黑色外刺**的完整图标（任务书 §2.3 点名）。
- 需要**独立可裁切的图**（不是混在界面截图角落的小图），且能确认是 **P5 原版**而非 P5R/P5X 变体。
- 可追溯来源优先级：官方素材站（Spriters Resource 等）> 官方设定集扫描 > 可核实出处的截图。
  Wiki 页面（如 [Megaten Wiki](https://megatenwiki.com/wiki/Metaverse_Navigator)）只能作为**线索**，
  需继续定位其引用的原图。

### G4 图片消息帧来源核实

- 已有 `p5r-sns--4aa5330b1fe6.jpg`（本地截图，167 KB）—— 内容可用，但**原始发布 URL 未核实**。
- 补：找到该图出处并记录；找不到则在映射表标注「来源不明」，**不补写推测 URL**。

## 3. 补齐后的回填要求

补到参考后，在 `docs/design-references/icon-mapping.md` 的「参考帧清单」表里：

| 字段 | 要求 |
| --- | --- |
| 位置 | 本地路径（参考库，只读） |
| 游戏版本 | P5 / P5R / P5X，**分开记**，不用相近名称替代 |
| 语言 | JPN / CN-JP / ENG |
| 来源 | 素材站页面 URL；视频则给链接 + 时间点 |
| 用途 | 一句话说明它证明哪一项布局 |

## 4. 验收口径（防止「看起来像」就宣布完成）

- 有参考帧 + 有**同状态**的实现截图（同视口）才能勾「还原完成」；
- 只有元件表、没有整屏参考 → 该状态只能勾「结构适配」，**不能勾还原**；
- 参考帧存在但实现截图缺失 → 同样不能勾。

## 5. 当前各 App 的还原验收状态（据本清单）

| App / 状态 | 参考 | 可以声称 |
| --- | --- | --- |
| IM 角色列表 | 元件表 + 教程合图小图 | 结构适配（**非还原**） |
| IM 普通文字消息 | ❌ 无（G1） | **参考未补齐** |
| IM 剧情回复 | ✅ 有（G2 已补齐） | **参考已补齐，站点回复选项已按帧改为白色箭头条** |
| IM 图片消息 | ⚠️ 有 1 张（G4 来源待核） | 结构适配 + 待核来源 |
| IM 自由聊天 | ❌ 无 | **参考未补齐** |
| 异世界导航图标 | ❌ 无（G3） | **参考未补齐** |
| 手记 / 放课后 / COOP / 殿堂 / 天鹅绒 | 各有母版（日历 / 迷你游戏+商店 / 阿卡那 / 照片集 / 蓝室） | 结构适配为主，逐项另记 |

---

## 6. 有图像能力的复核结果（2026-10-17，第二轮交接后）

> 背景：交接包（`docs/handoff-package-2026-10-17.zip`）把「缺参考帧 + 执行模型无图像输入」
> 列为唯一硬阻塞。本节由具备图像输入能力的复核者补做：**先找帧、再判定能还原到什么程度**。

### 6.1 本地参考库全量审计（找 G1/G2/G3）

| 资源 | 审计方式 | 结论 |
| --- | --- | --- |
| **P5 Official Design Works 画册 200dpi 页扫**（`persona-dist/reference-books/.../pages-200dpi/`，259 页） | 生成 5 张总览对照图（每页缩略 + 页码），人眼逐页扫；对疑似 UI 区（p205–244）另做高分辨率对照 | **没有 IM / 手机整屏 UI 设计页**。画册内容为角色设定、异世界/城镇背景、Persona、暗影、道具 UI 元件、棋盘/扑克/塔罗牌面、故事板。UI 元件页（p221–222 联系人与 Persona 图标群、p217–219 卡牌）可作图标素材来源，但不是整屏参考帧 |
| **HUD sprite 表**（`persona5-spriters/p5/hud` 22 张 + `p5r/hud` 8 张） | 逐张看图；P0 已提取 563 sprite | 有头像/按钮字形/日历/存档/商店/网络界面**元件**；**没有** IM 整屏、没有剧情回复选项、**没有异世界导航红眼图标**（P5 的导航图标不在这批 HUD 表里） |
| **SNS / IM 图片**（`persona-dist/media/image/**`） | 文件名 + 全量看 P5/P5R/P5X 目录 | 唯一完整 IM 屏 = `P5R/p5r-sns--4aa5330b1fe6.jpg`；其余是角色插画 / 战斗 / 商品图；P5X 的 `snsicon*` 是另一款游戏的 SNS 图标，**不能当 P5 原版参考** |
| **视频**（`persona-dist/media/video/**`） | 文件名筛查（sns/phone/chat/im） | 无 SNS/IM 界面视频 |

### 6.2 唯一完整 IM 屏的参考分析（`p5r-sns--4aa5330b1fe6.jpg`，1920×1080）

可确认的布局语言（用于 `P2-im-visual-restore-result.md` 的还原）：

| 元素 | 参考帧表现 | 本站实现（v1，2026-10-17） |
| --- | --- | --- |
| 画面底色 | 正红（约 `#a90d12`～`#c00d12`）带暗色细点纹理 | `.msg-app` 红底 + `var(--dots)` 点纹 ✅ |
| 面板 | 黑色整块 + 白色 2–3px 硬边，整体带 1–5° 倾斜 | 会话头 / 气泡 / 选项条全部黑底白框 + 小角度倾斜 ✅ |
| 应用标识 | 左上「IM」字样（白字 + 红色块） | 新增 `.msg-logo`（黑底白字 + 红块，P5Ransom 字体）✅ |
| 头像 | 黑白 sprite 装进**白色拍立得框**，旋转后叠在面板边缘 | 头像容器改白框 + 硬阴影 + 旋转 ✅ |
| 文字消息 | 白字压在黑色面板上，行距宽松 | 气泡黑底纸白字；我方消息反白 ✅ |
| 图片消息 | 照片装倾斜白边框；发送者头像做成贴纸叠在照片角落 | ⛔ 未做：消息模型无图片字段（B4） |
| 底部提示 | 白色 P5 撕纸字「Scroll / Next」+ 手柄字形 | ⛔ 未做（本站不用手柄字形；可后续用键盘提示语言） |

### 6.3 判定

- **G1 部分解除**：可以做文字消息与整屏布局语言的还原（已按 §6.2 落地 v1），
  但不足以宣称「普通文字消息整屏逐像素还原」——参考帧是群聊语境、缺两条往返与时间戳位置。
- **G2 已解除（2026-10-18）**：回复选择整屏由站主提供；站点回复选项已按帧改形。
- **G3 未解除**：异世界导航红眼图标本地库无原图；需要外部可追溯来源或用户提供。
- 因此：**「整屏视觉还原」仍不能标为通过**，缺口逐项保留。

### 6.4 手记日历（第二轮 §4.3）的参考判定

- 可用：`92140-save-load.png`（存档/读取元件）、`92120-calendar-jpn.png`（日历/星期/时段撕纸元件）。
- **缺**：完整「日历 / 手帐」整屏帧（本地画册 259 页已逐页审计，无该页；HUD 表只有元件）。
- 结论：日历视觉只做**元件语言级还原**（2026-10-17 v1，见 `P3-journal-calendar-visual-result.md`），
  日期锚点大日号/撕纸条/选中反白均来自元件表；**整屏还原仍标未完成**。

### 6.5 放课后（第二轮 §4.4）的参考判定

- 可用：`92712-shops.png`（商店/道具选择元件：NEW、价格白药丸、購入/やめる、所持数、半額、星级）、
  `92198-weapon-shop.png`（商品列表 + 详情构图）、画册 p205–224 道具 UI 元件页。
- **缺**：放课后（书籍/游戏记录）整屏帧；本地库没有该界面截图。
- 结论：做**道具/记录选择界面语言**级还原（2026-10-17 v1，见
  `P3-leisure-visual-result.md`），**整屏还原仍标未完成**。

### 6.6 我的殿堂（第二轮 §4.6）的参考判定

- 可用：画册 p219 阿卡那卡牌页（白卡边/红场/卡下撕纸标签的展陈语言）、站点既有撕纸与
  白框黑底语言（COOP 卡牌、手记存档）。
- **缺**：我的殿堂（作品展厅）整屏帧；本地库没有该界面截图，P5R Thieves Den 素材不在库中。
- 结论：做**展陈/收藏式界面语言**级还原（2026-10-17 v1，见
  `P3-showcase-visual-result.md`），**整屏还原仍标未完成**。
- 生活图库（`/gallery`）：本地参考只有 `p5r/hud/132783-photos-im.png`（P5R 相册照片本身，
  黑底 + 白框照片的展示语言），**没有照片查看器整屏帧**；2026-10-17 做记忆展示语言 v1
  （见 `P3-gallery-visual-result.md`），整屏还原仍标未完成。

### 6.7 异世界导航（第二轮 §4.7）的参考判定

- 可用：站点既有红黑白 / 撕纸 / 白框黑底语言；`92798-network-jpn.png`（P5 网络统计界面元件，
  只借仪表读数气质）。
- **缺**：异世界导航整屏帧；**经典红眼图标原图仍缺（G3）** —— 本地库已全量核对，
  P5 22 张 + P5R 8 张 HUD 表均无该图标，P5X 的 SNS 图标不能冒充。
- 结论：做「关键词输入构图 + 已发现殿堂列表」的视觉语言 v1（2026-10-17，见
  `P3-metanav-visual-result.md`），**整屏还原与图标均仍标未完成**。

### 6.8 天鹅绒房间 / 印象空间（第二轮 §4.8）的参考判定

- 可用：`92152-velvet-prison.png`（天鹅绒牢房元件表：蓝黑背景、冷光、"名簿记载"网格、
  現在のステータス 白色栏目牌、撕裂字体）；T09 已建立的冷色主题只在 `.plv-room` 子树内生效。
- **缺**：天鹅绒房间整屏帧；印象空间整屏帧。
- 结论：天鹅绒做**登记簿/冷色号牌**级视觉细化 v1（2026-10-17，见
  `P3-velvet-phone-registration-result.md`）；印象空间做**问题档案（暗紫品红）**级视觉
  细化 v1（2026-10-17，见 `P3-mementos-visual-result.md`）。
  两者**整屏还原仍标未完成**。

## 7. 2026-10-18 补帧记录（验收 v2 §5.1 / §7.3，共 22 张完整帧）

> 执行方式：Yandex 图片检索定位候选 → 下载 → 人眼逐帧核对 → dHash 与本地帧交叉比对 →
> 写入外部精选库 `persona-curated/hud/` → 仓库脚本复验哈希。
> 逐帧画面复核均为「无明智吾郎」；来源/许可一律「未核实」口径，不冒充官方授权素材。

| 帧（`persona-curated/hud/`） | 用途 | 来源 | 规格 / SHA-256 | 画面复核 |
| --- | --- | --- | --- | --- |
| `p4-dialogue-choice-fullframe.jpg` | P4/P4G 对话选项（**辅助参考，R1 纠正**） | Game UI Database 图片直链：`https://www.gameuidatabase.com/uploads/Persona-402132021-025557-75229.jpg` | 1920×1080 / `2392b491…` | P4 Fox 事件 3 选项（Ask for healing 等）；无明智；**非 P5R，不用于 G2** |
| `p5r-dialogue-normal-fullframe.jpg` | G1 普通对话完整帧 | **PlayStation 官方图片 CDN**：`https://image.api.playstation.com/vulcan/ap/rnd/202209/0202/QZuvnoBy0DhHj8CH5znQLIpL.jpg` | 3840×2160 / `7ca48c1b…` | Shadow Kamoshida 场景；与本地 screenshot-04 dHash 距离 1（同帧） |
| `p5r-dialogue-maruki-fullframe.jpg` | G1 普通对话完整帧 | 本地导入 `persona-dist/.../screenshot-01`（原始 URL 未核实；文件名内嵌 SHA-256 前缀 `feabb359…`） | 1920×1080 / `feabb359…` | 教室 + Maruki + 文本框；无明智 |
| `p5r-im-groupchat-fullframe.jpg` | IM 完整屏（群聊） | Pinterest 图片直链（原始发布 URL 未核实）：`https://i.pinimg.com/originals/8e/fc/c1/8efcc13d4eae5df544dadf98c202bd47.jpg` | 1280×720 / `44b761f4…` | Ryuji/Makoto 头像 + 3 条对方消息 + 底部提示；无明智 |
| `p5r-im-photo-fullframe.jpg` | IM 完整屏（含图片消息） | 本地导入 `p5r-sns--4aa5330b1fe6.jpg`（G4 口径：原始 URL 未核实） | 1920×1080 / `4aa5330b…` | 手机 + IM 列表 + 图片消息 + 气泡；无明智 |
| `p5r-street-hud-fullframe.jpg` | 手机 HUD 完整帧 | 本地导入 `screenshot-07`（原始 URL 未核实；文件名内嵌 SHA-256 前缀 `c56d8e14…`） | 1920×1080 / `c56d8e14…` | 日期/天气 + IM 通知图标（红 IM + 角标 3）+ 小地图 + 地点 toast；无明智 |

### 7.2 第二批：P5 完整帧（Game UI Database 归档页 id=72，2026-10-18）

| 帧（`persona-curated/hud/`） | 用途 | 来源 | 规格 / SHA-256 | 画面复核 |
| --- | --- | --- | --- | --- |
| `p5-load-save-fullframe.jpg` | **存档/读取整屏帧** | `https://www.gameuidatabase.com/uploads/Persona-511142020-081633-99804.jpg` | 1920×1080 / `65f9e7ff…` | Load 标题 + 存档槽 No.1–No.5 + 进度/难度/游玩时间；无明智 |
| `p5-phone-home-fullframe.jpg` | 手机主屏完整帧 | `https://www.gameuidatabase.com/uploads/Persona504202020-044600.jpg` | 1920×1080 / `25549fa5…` | P5 手机 App 网格（红眼导航/IM/地图/相机）+ 对话提示；无明智 |
| `p5-calendar-fullframe.jpg` | 日历整屏帧（手记参考） | `https://www.gameuidatabase.com/uploads/Persona-511142020-082022-80721.jpg` | 1920×1080 / `eb1bbf4d…` | 月历 + TODAY + Day/Night Job；无明智 |
| `p5-status-fullframe.jpg` | 五维状态整屏帧（人物档案参考） | `https://www.gameuidatabase.com/uploads/Persona-511142020-082022-55919.jpg` | 1920×1080 / `7a613ba1…` | LV/HP/SP + 五维属性；无明智 |
| `p5-map-school-fullframe.jpg` | 校内地图整屏帧 | `https://www.gameuidatabase.com/uploads/Persona-511142020-082124-80802.jpg` | 1920×1080 / `1c9e0717…` | Shujin Academy 1F 平面图 + 图例；无明智 |
| `p5-tokyo-map-fullframe.jpg` | **P5R 东京地点选择地图完整帧（R1 纠正版）** | Sketchfab 模型预览图（P5R 地图 UI）：`https://media.sketchfab.com/models/a8fd2793e583446e9509cf65f350fb9d/thumbnails/adb0aa09aa80478e91e7ae3f5ac4b0ba/e660c92572ad4b6ea0b712bee0928671.jpeg` | 1920×1080 / `682985c6…` | 红底东京地图 + 各站图标 + P5R 标志；无角色/无明智 |
| `p5-date-progress-city-fullframe.jpg` | P5 日期推进/城市背景（**非地图界面，R1 纠正**） | `https://www.gameuidatabase.com/uploads/Persona504202020-044456.jpg` | 1920×1080 / `b5036e93…` | 8–13 日星期标签 + 城市背景；无明智 |

### 7.3 第三批：界面整屏帧（天鹅绒/印象空间/COOP/殿堂/放课后，2026-10-18）

| 帧（`persona-curated/hud/`） | 用途 | 来源 | 规格 / SHA-256 | 画面复核 |
| --- | --- | --- | --- | --- |
| `p5r-velvet-room-fullframe.jpg` | **P5R 天鹅绒房间完整帧（R1 纠正版）** | Game UI Database：`https://www.gameuidatabase.com/uploads/Persona-5-Royal03112021-110116-38024.jpg` | 1920×1080 / `cd13dca0…` | P5R 蓝色天鹅绒牢房内景 + Lavenza；无明智 |
| `p4-velvet-room-fullframe.jpg` | P4 天鹅绒房间轿车内景（**辅助参考，R1 纠正**） | `https://i.playground.ru/i/pix/3183010/image.jpg` | 3840×2160 / `2ee23c93…` | P4 轿车内景 + Igor/Margaret；无明智；**非 P5R** |
| `p5r-im-inbox-fullframe.jpg` | P5R IM 收件列表（R1 补） | Game UI Database：`https://www.gameuidatabase.com/uploads/Persona-5-Royal03112021-110210-20416.jpg` | 1920×1080 / `06459056…` | IM 列表（Sumire/HOLD/NEW/日期）；无明智 |
| `p5r-im-conversation-fullframe.jpg` | P5R IM 会话（R1 补；**无回复选项**） | `https://cdn.wccftech.com/wp-content/uploads/2020/02/Persona-5-Royal-IM-Conversation.jpg` | 1920×1080 / `dac6193a…` | 手部持机 + 倾斜红面板 + 消息 + Reply 提示；无明智 |
| `p5-mementos-fullframe.jpg` | **印象空间整屏帧** | `https://blogger.googleusercontent.com/.../s1600/p5-07.png` | 800×447 / `e94b414f…` | Mementos「Aiyatsbus: Area 1」+ HUD；无明智（原图分辨率较低，如实记录） |
| `p5r-coop-confidant-fullframe.jpg` | **COOP 协助者整屏帧** | `https://telegra.ph/file/00eba9dd4038e3fca38c5.jpg` | 1400×788 / `b3ef4cc5…` | CONFIDANT / Arcana Fool / RANK 1 / NEW ABILITY；无明智 |
| `p5-palace-treasure-fullframe.jpg` | **殿堂整屏帧** | `https://i.ytimg.com/vi/RFZtVfi35PE/maxresdefault.jpg` | 1280×720 / `a5e4d4ce…` | 宫殿宝库内景 + Futaba 对话；无明智 |
| `p5-leisure-batting-fullframe.jpg` | **放课后整屏帧** | `https://cdn.segmentnextimages.com/wp-content/uploads/2023/06/persona-5-batting-cage.jpg` | 1281×723 / `69aeee91…` | 打击练习场 HOMERUN 记分牌 + Swing/Stop；无明智 |

复验脚本：`python3 tools/acceptance/verify-reference-frames.py`（**22/22** 帧存在、哈希/尺寸/索引/来源一致；
参考库不存在时 SKIP）。整屏帧覆盖已补，**G2 已由站主提供**；
仍缺：真实设备渲染证据、IM 图片消息协议后续阶段（B4 Phase 2/3）。

**来源核实（2026-10-18）**：见 `reference-frame-sources.md` —— 22 帧中 **官方 3 张**
（PlayStation CDN 1 + Steam 官方商店截图 2，dHash 0/1 同帧核对）、可追溯非官方 12 张、
未核实 2 张（P5R IM 帧，G4 口径保留未核实）。
